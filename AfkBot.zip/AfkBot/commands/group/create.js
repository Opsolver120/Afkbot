const { SlashCommandBuilder } = require('discord.js');
const groupService = require('../../services/groupService');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('group-create')
        .setDescription('Create a new bot group')
        .addStringOption(opt => opt.setName('name').setDescription('Group name').setRequired(true)),
    async execute(interaction) {
        const name = interaction.options.getString('name');
        const success = await groupService.createGroup(name);
        
        if (!success) return interaction.reply('Group already exists.');
        await interaction.reply(`Group **${name}** created.`);
    }
};