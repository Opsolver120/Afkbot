const { SlashCommandBuilder } = require('discord.js');
const groupService = require('../../services/groupService');
const botManager = require('../../bots/botManager');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('group-run')
        .setDescription('Execute a command on all bots in a group')
        .addStringOption(opt => opt.setName('group').setDescription('Group name').setRequired(true))
        .addStringOption(opt => opt.setName('command').setDescription('Message/Command').setRequired(true)),
    async execute(interaction) {
        const groupName = interaction.options.getString('group');
        const cmd = interaction.options.getString('command');
        const group = await groupService.getGroup(groupName);

        if (!group) return interaction.reply('Group not found.');

        let count = 0;
        group.bots.forEach(botName => {
            const bot = botManager.getBot(botName);
            if (bot && bot.isConnected) {
                bot.chat(cmd);
                count++;
            }
        });

        await interaction.reply(`Executed command on **${count}** bots in group **${groupName}**.`);
    }
};