const { SlashCommandBuilder } = require('discord.js');
const groupService = require('../../services/groupService');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('group-add')
        .setDescription('Add a bot to a group')
        .addStringOption(opt => opt.setName('group').setDescription('Group name').setRequired(true))
        .addStringOption(opt => opt.setName('bot').setDescription('Bot name').setRequired(true)),
    async execute(interaction) {
        const groupName = interaction.options.getString('group');
        const botName = interaction.options.getString('bot');
        
        const success = await groupService.addBotToGroup(groupName, botName);
        if (!success) return interaction.reply('Failed to add bot to group.');

        await interaction.reply(`Bot **${botName}** added to group **${groupName}**.`);
    }
};