const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const botManager = require('../../bots/botManager');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('status')
        .setDescription('Show status of all bots'),
    async execute(interaction) {
        const bots = botManager.getAllBots();
        const embed = new EmbedBuilder()
            .setTitle('System Bot Status')
            .setColor('#00ff00');

        if (bots.length === 0) {
            embed.setDescription('No bots configured.');
        } else {
            const statusList = bots.map(b => `${b.isConnected ? '✅' : '❌'} **${b.name}** (${b.config.host})`).join('\n');
            embed.setDescription(statusList);
        }

        await interaction.reply({ embeds: [embed] });
    }
};