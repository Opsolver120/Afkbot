const { SlashCommandBuilder } = require('discord.js');
const { ownerId } = require('../../config.json');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('console')
        .setDescription('Owner only console execution')
        .addStringOption(opt => opt.setName('cmd').setDescription('Eval command').setRequired(true)),
    async execute(interaction) {
        if (interaction.user.id !== ownerId) {
            return interaction.reply({ content: 'Unauthorized.', ephemeral: true });
        }

        const code = interaction.options.getString('cmd');
        try {
            let evaled = eval(code);
            await interaction.reply(`\`\`\`js\n${evaled}\n\`\`\``);
        } catch (err) {
            await interaction.reply(`\`ERROR\` \`\`\`xl\n${err}\n\`\`\``);
        }
    }
};