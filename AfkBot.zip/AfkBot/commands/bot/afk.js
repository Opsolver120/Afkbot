const { SlashCommandBuilder } = require('discord.js');
const botManager = require('../../bots/botManager');
const config = require('../../config.json');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('bot-afk')
        .setDescription('Toggle Anti-AFK for a bot')
        .addStringOption(opt => opt.setName('name').setDescription('Bot name').setRequired(true))
        .addBooleanOption(opt => opt.setName('enabled').setDescription('Enable or Disable').setRequired(true))
        .addIntegerOption(opt => opt.setName('interval').setDescription('Interval in seconds')),
    async execute(interaction) {
        const name = interaction.options.getString('name');
        const enabled = interaction.options.getBoolean('enabled');
        const interval = interaction.options.getInteger('interval') || (config.defaultAntiAfkInterval / 1000);
        
        const bot = botManager.getBot(name);
        if (!bot) return interaction.reply('Bot not found.');

        bot.toggleAfk(enabled, interval * 1000);
        await interaction.reply(`Anti-AFK for **${name}** set to **${enabled}** (Interval: ${interval}s)`);
    }
};