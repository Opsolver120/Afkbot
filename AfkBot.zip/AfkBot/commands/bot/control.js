const { SlashCommandBuilder } = require('discord.js');
const botManager = require('../../bots/botManager');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('bot-control')
        .setDescription('Control bot movement')
        .addStringOption(opt => opt.setName('name').setDescription('Bot name').setRequired(true))
        .addStringOption(opt => opt.setName('action').setDescription('Action to perform').setRequired(true)
            .addChoices(
                { name: 'Jump', value: 'jump' },
                { name: 'Rotate', value: 'rotate' }
            )),
    async execute(interaction) {
        const name = interaction.options.getString('name');
        const action = interaction.options.getString('action');
        const bot = botManager.getBot(name);

        if (!bot || !bot.isConnected) return interaction.reply('Bot is not connected.');

        if (action === 'jump') bot.movement.jump();
        if (action === 'rotate') bot.movement.rotate(90);

        await interaction.reply(`Action **${action}** sent to **${name}**.`);
    }
};