const { SlashCommandBuilder } = require('discord.js');
const botManager = require('../../bots/botManager');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('bot-connect')
        .setDescription('Connect a bot to a server')
        .addStringOption(opt => opt.setName('name').setDescription('Bot name').setRequired(true)),
    async execute(interaction) {
        const name = interaction.options.getString('name');
        const bot = botManager.getBot(name);

        if (!bot) return interaction.reply('Bot profile not found.');
        
        await interaction.reply(`Attempting to connect **${name}**...`);
        
        bot.once('ready', () => {
            interaction.followUp(`Bot **${name}** is now online!`);
        });

        bot.connect();
    }
};