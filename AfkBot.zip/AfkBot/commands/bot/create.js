const { SlashCommandBuilder } = require('discord.js');
const botManager = require('../../bots/botManager');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('bot-create')
        .setDescription('Create a new Bedrock bot profile')
        .addStringOption(opt => opt.setName('name').setDescription('Unique bot name').setRequired(true))
        .addStringOption(opt => opt.setName('host').setDescription('Server IP').setRequired(true))
        .addIntegerOption(opt => opt.setName('port').setDescription('Server Port').setRequired(true))
        .addStringOption(opt => opt.setName('username').setDescription('Minecraft Username').setRequired(true)),
    async execute(interaction) {
        const name = interaction.options.getString('name');
        const host = interaction.options.getString('host');
        const port = interaction.options.getInteger('port');
        const username = interaction.options.getString('username');

        const bot = botManager.createBot({ name, host, port, username });
        if (!bot) return interaction.reply('Bot with that name already exists!');

        await interaction.reply(`Bot profile **${name}** created successfully.`);
    }
};