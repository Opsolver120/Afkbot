const { SlashCommandBuilder } = require('discord.js');
const botManager = require('../../bots/botManager');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('bot-chat')
        .setDescription('Send a message to Minecraft chat')
        .addStringOption(opt => opt.setName('name').setDescription('Bot name').setRequired(true))
        .addStringOption(opt => opt.setName('message').setDescription('Message to send').setRequired(true)),
    async execute(interaction) {
        const name = interaction.options.getString('name');
        const message = interaction.options.getString('message');
        const bot = botManager.getBot(name);

        if (!bot || !bot.isConnected) return interaction.reply('Bot is not connected.');

        bot.chat(message);
        await interaction.reply(`[${name}] Sent: ${message}`);
    }
};