const DiscordClient = require('./core/discordClient');
const botManager = require('./bots/botManager');
const Logger = require('./core/logger');

async function bootstrap() {
    Logger.info('Starting Bedrock AFK System...');
    
    try {
        // Initialize Storage and Bot Manager
        await botManager.init();
        
        // Initialize Discord System
        await DiscordClient.init();

        // Handle process termination
        process.on('SIGINT', async () => {
            Logger.warn('Shutting down...');
            const bots = botManager.getAllBots();
            for (const bot of bots) {
                bot.disconnect();
            }
            process.exit(0);
        });

    } catch (error) {
        Logger.error('Bootstrap Critical Failure', error);
    }
}

bootstrap();