const BotInstance = require('./botInstance');
const storage = require('../services/storageService');
const Logger = require('../core/logger');

class BotManager {
    constructor() {
        this.bots = new Map();
    }

    async init() {
        const botConfigs = await storage.load('bots');
        for (const config of botConfigs) {
            this.createBot(config, false);
        }
        Logger.info(`Initialized BotManager with ${this.bots.size} bots.`);
    }

    createBot(config, save = true) {
        if (this.bots.has(config.name)) return null;
        
        const bot = new BotInstance(config);
        this.bots.set(config.name, bot);

        if (save) {
            this.saveBots();
        }
        return bot;
    }

    async saveBots() {
        const configs = Array.from(this.bots.values()).map(b => b.config);
        await storage.save('bots', configs);
    }

    getBot(name) {
        return this.bots.get(name);
    }

    getAllBots() {
        return Array.from(this.bots.values());
    }

    removeBot(name) {
        const bot = this.bots.get(name);
        if (bot) {
            bot.disconnect();
            this.bots.delete(name);
            this.saveBots();
            return true;
        }
        return false;
    }
}

module.exports = new BotManager();