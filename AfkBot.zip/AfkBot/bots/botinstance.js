const bedrock = require('bedrock-protocol');
const MovementEngine = require('./movement');
const Logger = require('../core/logger');
const EventEmitter = require('events');

class BotInstance extends EventEmitter {
    constructor(config) {
        super();
        this.config = config;
        this.name = config.name;
        this.client = null;
        this.runtimeId = null;
        this.movement = new MovementEngine(this);
        this.isConnected = false;
        this.afkInterval = null;
        this.reconnectAttempts = 0;
    }

    async connect() {
        Logger.bot(this.name, `Connecting to ${this.config.host}:${this.config.port}...`);
        
        try {
            this.client = bedrock.createClient({
                host: this.config.host,
                port: this.config.port,
                username: this.config.username,
                offline: this.config.offline || true,
                version: this.config.version
            });

            this.setupListeners();
        } catch (err) {
            Logger.error(`Connection failed for ${this.name}`, err);
            this.handleReconnect();
        }
    }

    setupListeners() {
        this.client.on('start_game', (packet) => {
            this.runtimeId = packet.runtime_entity_id;
            this.isConnected = true;
            Logger.bot(this.name, 'Spawned in world.');
            this.emit('ready');
        });

        this.client.on('text', (packet) => {
            if (packet.message) {
                this.emit('chat', {
                    source: packet.source_name,
                    message: packet.message
                });
            }
        });

        this.client.on('disconnect', (packet) => {
            Logger.warn(`${this.name} disconnected: ${packet.reason}`);
            this.cleanup();
            this.handleReconnect();
        });

        this.client.on('error', (err) => {
            Logger.error(`Socket error for ${this.name}`, err);
            this.cleanup();
            this.handleReconnect();
        });

        this.client.on('player_auth_input', (packet) => {
            this.movement.updatePosition(packet);
        });
    }

    async chat(message) {
        if (!this.client) return;
        this.client.queue('text', {
            type: 'chat',
            needs_translation: false,
            source_name: this.client.username,
            xuid: '',
            platform_chat_id: '',
            message: message
        });
    }

    toggleAfk(enabled, intervalMs = 30000) {
        if (this.afkInterval) clearInterval(this.afkInterval);
        if (enabled) {
            this.afkInterval = setInterval(() => {
                this.movement.jump();
                this.movement.rotate(Math.random() * 360);
            }, intervalMs);
            Logger.bot(this.name, 'Anti-AFK Enabled');
        } else {
            this.afkInterval = null;
            Logger.bot(this.name, 'Anti-AFK Disabled');
        }
    }

    handleReconnect() {
        this.isConnected = false;
        setTimeout(() => {
            Logger.bot(this.name, 'Attempting auto-reconnect...');
            this.connect();
        }, 5000);
    }

    cleanup() {
        this.isConnected = false;
        if (this.afkInterval) clearInterval(this.afkInterval);
        if (this.client) this.client.close();
    }

    disconnect() {
        this.cleanup();
        this.client = null;
    }
}

module.exports = BotInstance;