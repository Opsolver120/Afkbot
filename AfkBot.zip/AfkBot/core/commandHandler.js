// Dynamic loader already integrated into discordClient.js for efficiency
module.exports = {}; 