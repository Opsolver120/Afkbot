const { Client, GatewayIntentBits, Collection, REST, Routes } = require('discord.js');
const fs = require('fs');
const path = require('path');
const config = require('../config.json');
const Logger = require('./logger');

class DiscordClient {
    constructor() {
        this.client = new Client({
            intents: [
                GatewayIntentBits.Guilds,
                GatewayIntentBits.GuildMessages,
                GatewayIntentBits.MessageContent
            ]
        });
        this.commands = new Collection();
    }

    async init() {
        await this.loadCommands();
        await this.registerSlashCommands();
        
        this.client.on('interactionCreate', async interaction => {
            if (!interaction.isChatInputCommand()) return;
            const command = this.commands.get(interaction.commandName);
            if (!command) return;

            try {
                await command.execute(interaction);
            } catch (error) {
                Logger.error('Command Execution Error', error);
                await interaction.reply({ content: 'Internal error executing command.', ephemeral: true });
            }
        });

        this.client.login(config.token);
        this.client.once('ready', () => {
            Logger.success(`Discord Bot logged in as ${this.client.user.tag}`);
        });
    }

    async loadCommands() {
        const foldersPath = path.join(__dirname, '../commands');
        const commandFolders = fs.readdirSync(foldersPath);

        for (const folder of commandFolders) {
            const commandsPath = path.join(foldersPath, folder);
            const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));
            for (const file of commandFiles) {
                const filePath = path.join(commandsPath, file);
                const command = require(filePath);
                if ('data' in command && 'execute' in command) {
                    this.commands.set(command.data.name, command);
                }
            }
        }
    }

    async registerSlashCommands() {
        const rest = new REST().setToken(config.token);
        try {
            const body = this.commands.map(cmd => cmd.data.toJSON());
            await rest.put(
                Routes.applicationCommands(config.clientId),
                { body: body }
            );
            Logger.info('Successfully reloaded application (/) commands.');
        } catch (error) {
            Logger.error('Failed to register commands', error);
        }
    }
}

module.exports = new DiscordClient();