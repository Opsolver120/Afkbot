const chalk = require('chalk');

class Logger {
    static info(message) {
        console.log(`${chalk.blue('[INFO]')} ${chalk.white(message)}`);
    }

    static success(message) {
        console.log(`${chalk.green('[SUCCESS]')} ${chalk.white(message)}`);
    }

    static warn(message) {
        console.log(`${chalk.yellow('[WARN]')} ${chalk.white(message)}`);
    }

    static error(message, trace) {
        console.error(`${chalk.red('[ERROR]')} ${chalk.white(message)}`);
        if (trace) console.error(trace);
    }

    static bot(name, message) {
        console.log(`${chalk.magenta(`[BOT:${name}]`)} ${chalk.white(message)}`);
    }
}

module.exports = Logger;