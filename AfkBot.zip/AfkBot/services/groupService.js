const storage = require('./storageService');

class GroupService {
    async createGroup(name) {
        const groups = await storage.load('groups');
        if (groups.find(g => g.name === name)) return false;
        groups.push({ name, bots: [] });
        await storage.save('groups', groups);
        return true;
    }

    async addBotToGroup(groupName, botName) {
        const groups = await storage.load('groups');
        const group = groups.find(g => g.name === groupName);
        if (!group) return false;
        if (!group.bots.includes(botName)) {
            group.bots.push(botName);
            await storage.save('groups', groups);
        }
        return true;
    }

    async getGroup(name) {
        const groups = await storage.load('groups');
        return groups.find(g => g.name === name);
    }
}

module.exports = new GroupService();