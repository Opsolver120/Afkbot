const fs = require('fs-extra');
const path = require('path');
const Logger = require('../core/logger');

class StorageService {
    constructor() {
        this.paths = {
            bots: path.join(__dirname, '../data/bots.json'),
            groups: path.join(__dirname, '../data/groups.json'),
            servers: path.join(__dirname, '../data/servers.json')
        };
    }

    async load(key) {
        try {
            return await fs.readJson(this.paths[key]);
        } catch (err) {
            Logger.error(`Failed to load ${key} data`, err);
            return [];
        }
    }

    async save(key, data) {
        try {
            await fs.writeJson(this.paths[key], data, { spaces: 2 });
        } catch (err) {
            Logger.error(`Failed to save ${key} data`, err);
        }
    }
}

module.exports = new StorageService();